
  # ChMS-by-Make

  This is a code bundle for ChMS-by-Make. The original project is available at https://www.figma.com/design/RFzrbbFTveD3cc2wlJ6571/ChMS-by-Make.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  